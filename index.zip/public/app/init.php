<?php

use ReCaptcha\ReCaptcha;
require_once '../vendor/autoload.php';

$recaptcha = new ReCaptcha('6LfEicYUAAAAAMoN7uLrPRdTVwgCqMGgQtNhVpS4');
?>