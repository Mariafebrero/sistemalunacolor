
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Sistema Luna Color</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="../../public/img/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../../public/vendor/bootstrap/css/bootstrap.min.css">
	<!-- ICONOS fontawesome --->
	<link rel="stylesheet" type="text/css" href="../../public/iconosfontawesome/css/all.css"> 
	<link rel="stylesheet" type="text/css" href="../../public/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="../../public/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../../public/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="../../public/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../../public/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../../public/vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="../../public/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../..//public/css/util.css">
	<link rel="stylesheet" type="text/css" href="../../public/css/main.css">
<!--=========================Sweet Alert========================================================-->
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<!--===============================================================================================-->
</head>
<body style="background-color: #666666;">


	<div class="limiter"  >
		<div class="container-login100" >
			<div class="wrap-login100">
				
				<form class="login100-form validate-form" method="post" autocomplete="off">

	<?php 
	include "../../config/Conglobal.php";



//------------------------------------- Nombre y token igual Inicio -------------------------------------

	$user_url = $_GET['user'];
	$token_url = $_GET['lunaverificationcode'];
	date_default_timezone_set("America/Tegucigalpa"); 
	$factual = strtotime("now");
    $factual = date("d-m-Y H:i:s", $factual);
    $userbase = NULL;
    $fecha_finalbase = NULL;
   

	$sql= "select * from tbl_usuarios where usuario=" . "'". $user_url . "'". "and token = " . "'". $token_url . "'". " ";

	$query = $con->query($sql);

	while ($r=$query->fetch_array()) 
			{
				$userid=$r["id_usuario"];
				$userbase=$r["usuario"];
				$user_tokenbase = $r["token"];
				$fecha_inicialbase = $r["fecha_inicio"];
				$fecha_finalbase = $r["fecha_final"];
				break;
			}

//------------------- Consultas para el parametro de MIN y MAX de la contraseña INICIO -------------------

	$sql= "select valor FROM `tbl_parametros` WHERE parametro = 'MIN_CONTRASENA' ";

	$query = $con->query($sql);

	while ($r=$query->fetch_array()) 
			{
				$Mincontra=$r["valor"];
				break;
			}
			// Las usa en la linea 157 de aquí
			$MincontraLen = "minlength=" . "'" . $Mincontra . "'";

	$sql= "select valor FROM `tbl_parametros` WHERE parametro = 'MAX_CONTRASENA' ";

	$query = $con->query($sql);

	while ($r=$query->fetch_array()) 
			{
				$Maxcontra=$r["valor"];
				break;
			}
			// Las usa en la linea 157 de aquí
			$MaxcontraLen = "maxlength=" . "'" . $Maxcontra . "'";
//------------------- Consultas para el parametro de MIN y MAX de la contraseña FIN -------------------			
			strtoupper($userbase);
		//preguntar donde enviar
	if($user_url != $userbase or $token_url != $user_tokenbase)
			{
				// puede ser que ingreso a un link anterior
				//cambio manual de url
			echo "<script >
            swal({ title: '¡Hubo un error inesperado!',
          	text: 'contacte a su soporte técnico',
          	icon:'error',
         	type: 'error'}).then(okay => 
         	{
         	if (okay)
         	{
       			window.location='../login1.php';
       			exit();
      	 	}
      	 	else 
      	 	{
      	 		window.location='../login1.php';
      	 		exit();
      	 	}
      	 	
       		});
     			 </script>";
     			 exit();
		    }
			if ($factual >= $fecha_finalbase or $fecha_inicialbase >= $fecha_finalbase) 
			{ //fuera de tiempo, preguntar si manda al login o a solicitar nuevo codigo
				echo "<script >
            swal({ title: '¡Código expirado!',
          	text: 'Solicite un nuevo código',
          	icon:'error',
         	type: 'error'}).then(okay => 
         	{
         	if (okay)
         	{
       			window.location='../login1.php';
       			exit();
      	 	}
      	 	else 
      	 	{
      	 		window.location='../login1.php';
      	 		exit();
      	 	}
      	 	
       		});
     			 </script>";
     			 exit();
			}	
 //------------------------------------- Nombre y token igual fin -------------------------------------		
	?> 

		

				<h3 style = "position:relative;  top:-70px; color:#F27830"> <center> ¡Bienvenido
				<?php 	print $userbase;
	 			 ?>!
				<h5 style = "position:relative;  top:10px; color:#F27830" ><span class="hiddenui"><i> ¡Restablece tu contraseña!</i></span><hr></h5>
				
				</h3> </center>
		<!----------------------- Casilla de contraseña nueva--------------------->
					<div class="col-xs-12"  style = "position:relative;  top:-40px;">
      				 <p class="text-secondary float-left"> <h6> Ingrese su contraseña nueva </h6></p>
      				 <!--- posicion del boton-->
       				 <div class="input-group">
     					<input ID="Contranueva" type="Password" name="Contranueva" Class="form-control" pattern="^(?=.*\d)(?=.*[\u0021-\u002b\u003c-\u0040])(?=.*[A-Z])(?=.*[a-z])\S{5,10}$"<?php echo $MincontraLen . " " .  $MaxcontraLen; ?>  required onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" onDrag="return false" onDrop="return false" autocomplete=off/>
      					<div class="input-group-append">
            			<button id="show_password" class="login100-form-btn" name="eye1" type="button" onclick="mostrarPassword()" style="background-color: rgb(233,118,46)"> 
            				<h5><span class="fas fa-eye-slash icon"></span></h5></button>
          				</div>
    				</div>
                    </div>
                 
                   <br>
		<!---------------------------------- Casilla de confirmación----------------------------->
		
					<div class="col-xs-12" style = "position:relative;  top:-40px;">
      				 <p class="text-secondary float-left"> <h6> Confirme su contraseña nueva </h6></p>
       				 <div class="input-group">
     					<input Id="Contraconfir" type="password" name="Contraconfir" Class="form-control" pattern="^(?=.*\d)(?=.*[\u0021-\u002b\u003c-\u0040])(?=.*[A-Z])(?=.*[a-z])\S{5,10}$" <?php echo $Mincontra . " " .  $Maxcontra; ?>  required onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" onDrag="return false" onDrop="return false" autocomplete=off/>
      					<div class="input-group-append">
            			<button id="show_password2" class="login100-form-btn" name="eye2" type="button" onclick="mostrarPassword2()" style="background-color: rgb(233,118,46)"> 
            				<h5><span class="fas fa-eye-slash svg"></span></h5></button>
          				</div>
    				</div>
                    </div>
                    <br>
		<!---- Variables directas de SQL, sin modificar ------>
		<small style = "position:relative;  top:-50px;" >  *La contraseña debe tener entre <?php echo $Mincontra . " a " .  $Maxcontra; ?> letras, mínimo un número, una letra mayúscula y un símbolo.
	    </small> 
	    <br>
	    <br>

			<!----------------------- Botón actualizar---------------------------->
					<div style = "position:relative;  top:-70px;"  class="container-login100-form-btn"  >
						<div class="alert"><?php echo isset($alert) ? $alert : ''; ?></div>
						<button type="submit" name ="BotonValidar" class="login100-form-btn">
							Actualizar
						</button>
					</div>
			
					
				</form>


				 <!-- Fondo de login -->
				<div class="login100-more" style="background-image: url('../../public/img/FONDOS-04.SVG');">
				</div>
			</div>
		</div>
	</div>
	<!------------------------------- Código --------------------------------------->
	<?php
    include "../../config/Conglobal.php";
	?>

	<?php
	if(isset($_POST["BotonValidar"]))

	{
		if($_POST["Contranueva"]!="" &&$_POST["Contraconfir"]!="")
            $ContraNueva = ($_POST['Contranueva']);
            $Contraconfir = ($_POST['Contraconfir']);
		{
			if($ContraNueva === $Contraconfir)
			{
				include "../../config/Conglobal.php"; 
    //$contra2=$_POST['contrasena'];
    $EncripContra=hash("SHA256",$Contraconfir);

//---------------------------------- Ejecuciones SQL INICIO --------------------------------------
		$sql= "update tbl_usuarios set contrasena =" . "'" . $EncripContra . "'" . " WHERE usuario=" . "'" .  $userbase. "'". "";
		$query = $con->query($sql);

		$sql= "update tbl_usuarios set id_estado_usuario =2 WHERE usuario=" . "'" .  $userbase. "'". "";
		$query = $con->query($sql);
		//resetear token
		$sql= "update tbl_usuarios set fecha_inicio =" . "'" . $fecha_finalbase . "'" .  " WHERE usuario=" . "'" .  $userbase. "'". "";
		$query = $con->query($sql);
//---------------------------------- Ejecuciones SQL FIN ------------------------------------------------
 echo "<script >
           swal({ title: '¡El cambio se ha realizado con éxito!',
          text: ' ',
          icon:'success',
          type: 'success'}).then(okay => {
          if (okay)
          {
          window.location.href = '../login1.php';
          }
          else 
          {
 		 window.location.href = '../login1.php';
          }
       });
      </script>";

      include "../../config/Conglobal.php";


     	 $sql= 
     	 "INSERT INTO  tbl_bitacora(id_usuario,id_objeto,fecha,accion,descripcion,creado_por,fecha_creacion)
     	 VALUES('$userid','8',(select now()),'Entró','Entró a Validación de Recuperación Contraseña por Correo','$userbase',(select now()))";
 		 $con->query($sql);

 		 $sql= 
     	 "INSERT INTO  tbl_bitacora(id_usuario,id_objeto,fecha,accion,descripcion,creado_por,fecha_creacion)
     	 VALUES('$userid','8',(select now()),'Actualizó','Actualizó contraseña','$userbase',(select now()))";
 		 $con->query($sql);

 		  $sql= 
     	 "INSERT INTO  tbl_bitacora(id_usuario,id_objeto,fecha,accion,descripcion,creado_por,fecha_creacion)
     	 VALUES('$userid','8',(select now()),'Actualizó','Actualizó estado de usuario a: Activo','$userbase',(select now()))";
 		 $con->query($sql);

 		  $sql= 
     	 "INSERT INTO  tbl_bitacora(id_usuario,id_objeto,fecha,accion,descripcion,creado_por,fecha_creacion)
     	 VALUES('$userid','8',(select now()),'Salió','Salió de Validación de Recuperación Contraseña por Correo','$userbase',(select now()))";
 		 $con->query($sql);

 		  $sql= 
     	 "INSERT INTO  tbl_bitacora(id_usuario,id_objeto,fecha,accion,descripcion,creado_por,fecha_creacion)
     	 VALUES('$userid','5',(select now()),'Entró','Entró al login','$userbase',(select now()))";
 		 $con->query($sql);

		//print "<script>alert('¡El cambio se ha realizado con éxito!'); window.location='../Login.php';</script>";		
			}
			
			else
			  {
			  	//NO DEBE RECARGAR LA PÁGINA


echo"<script type='text/javascript'>		
	    swal('ERROR: Las contraseñas no coinciden entre si. Intentélo de nuevo o contacte a su soporte técnico.', '', 'error');
        </script>";

		//print "<script>alert(\"ERROR: Las contraseñas no coinciden entre si. Intentélo de nuevo o contacte a su soporte técnico.\")</script>";	
			  }
	}
}
	?>

	
	<!--===============================================================================================-->	


<script src="https://www.google.com/recaptcha/api.js"></script>
 <!--catcha-->
<!--===============================================================================================-->
	<script src="../../public/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="../../public/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="../../public/vendor/bootstrap/js/popper.js"></script>
	<script src="../../public/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="../../public/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="../../public/vendor/daterangepicker/moment.min.js"></script>
	<script src="../../public/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="../../public/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="../../public/js/main.js"></script>
<!--===============================================================================================-->


<!--===============================================================================================-->

<!--============================= Habilitar ver Nueva contraseña Inicio=================================-->
<script type="text/javascript">
function mostrarPassword()
{
		var cambio = document.getElementById("Contranueva");
		if(cambio.type == "password" )
		{ 
			cambio.type = "text";
			$('.icon').removeClass('fas fa-eye-slash').addClass('fas fa-eye');
		}
		else
		{
			cambio.type = "password";
			$('.icon').removeClass('fas fa-eye').addClass('fas fa-eye-slash');
		}
}  
	
</script>
					<style type="text/css">
						a{
							text-decoration: none;
							display: inline-flex;
							padding: 10px 10px;
						}
						a:hover{
							background-color: black;
							color: white;
							transition: 0.3s; 
							border-radius: 200px 200px 200px 200px;
                            -moz-border-radius: 200px 200px 200px 200px;
                            -webkit-border-radius: 200px 200px 200px 200px;
                            border: 0px solid #000000;
						}
						.previous{
							background-color: #E9762E;
							color:white;
							border-radius: 200px 200px 200px 200px;
                            -moz-border-radius: 200px 200px 200px 200px;
                            -webkit-border-radius: 200px 200px 200px 200px; 
                            border: 0px solid #000000;
						}
						.round{
							border-radius:100%;
						}

						.fas fa-eye-slash icon{
							background-color: #E9762E;
							color:white;
							border-radius: 200px 200px 200px 200px;
                            -moz-border-radius: 200px 200px 200px 200px;
                            -webkit-border-radius: 200px 200px 200px 200px; 
                            border: 0px solid #000000;
						}
					</style>



<!--============================= Habilitar ver Nueva contraseña FIN=================================-->
<!--============================= Habilitar ver Confirmar contraseña Inicio==========================-->
<script type="text/javascript">
function mostrarPassword2()
{
		var cambio2 = document.getElementById("Contraconfir");
		if(cambio2.type == "password")
		{
			cambio2.type = "text";
			$('.svg').removeClass('fas fa-eye-slash').addClass('fas fa-eye');
		}
		else
		{
			cambio2.type = "password";
			$('.svg').removeClass('fas fa-eye').addClass('fas fa-eye-slash');
		}
} 
	
</script>
					<style type="text/css">
						a{
							text-decoration: none;
							display: inline-flex;
							padding: 10px 10px;
						}
						a:hover{
							background-color: black;
							color: white;
							transition: 0.3s; 
							border-radius: 200px 200px 200px 200px;
                            -moz-border-radius: 200px 200px 200px 200px;
                            -webkit-border-radius: 200px 200px 200px 200px;
                            border: 0px solid #000000;
						}
						.previous{
							background-color: #E9762E;
							color:white;
							border-radius: 200px 200px 200px 200px;
                            -moz-border-radius: 200px 200px 200px 200px;
                            -webkit-border-radius: 200px 200px 200px 200px; 
                            border: 0px solid #000000;
						}
						.round{
							border-radius:100%;
						}

						.fas fa-eye-slash icon{
							background-color: #E9762E;
							color:white;
							border-radius: 200px 200px 200px 200px;
                            -moz-border-radius: 200px 200px 200px 200px;
                            -webkit-border-radius: 200px 200px 200px 200px; 
                            border: 0px solid #000000;
						}
					</style>


<!--============================= Habilitar ver Confirmar contraseña Final=========================-->
</body>

</html>
